const express = require('express');
const mysql = require('mysql');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors()); 

// Conectar a MySQL 
const db = mysql.createConnection({
  host: 'mariaforero.online',    
  user: 'u825759188_mariaforero',
  password: 'Mfc2379**',
  database: 'u825759188_casacuentos'
});

db.connect((err) => {
  if (err) {
    console.error('Error al conectar a la base de datos:', err);
  } else {
    console.log('Conexión exitosa a la base de datos.');
  }
});

// Ruta para registrar usuarios
app.post('/register', async (req, res) => {
  const { Nombre, Correo, Contraseña, TipoUsuario } = req.body;

  // Verifica si el correo ya existe
  db.query('SELECT * FROM usuarios WHERE Correo = ?', [Correo], async (err, result) => {
    if (err) return res.status(500).send('Error en el servidor');
    if (result.length > 0) {
      return res.status(400).send('El correo ya está registrado');
    }

    // Cifra la contraseña
    const hashedPassword = await bcrypt.hash(Contraseña, 8);

    // Inserta el nuevo usuario
    db.query('INSERT INTO usuarios SET ?', { Nombre, Correo, Contraseña: hashedPassword, TipoUsuario }, (err, result) => {
      if (err) return res.status(500).send('Error al registrar usuario');
      res.status(201).send('Usuario registrado con éxito');
    });
  });
});

// Ruta para iniciar sesión
app.post('/login', (req, res) => {
  const { Correo, Contraseña } = req.body;

  db.query('SELECT * FROM usuarios WHERE Correo = ?', [Correo], async (err, result) => {
    if (err) return res.status(500).send('Error en el servidor');
    if (result.length === 0) return res.status(400).send('Usuario no encontrado');

    const user = result[0];

    // Verifica la contraseña
    const isMatch = await bcrypt.compare(Contraseña, user.Contraseña);
    if (!isMatch) return res.status(400).send('Contraseña incorrecta');

    // Genera un token JWT
    const token = jwt.sign({ id: user.ID_Usuario }, 'secreto_jwt', { expiresIn: '1h' });
    res.json({ token });
  });
});

// Inicia el servidor en el puerto 5000
app.listen(5000, () => {
  console.log('Servidor iniciado en el puerto 5000');
});
