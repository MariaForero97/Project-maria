import React, { useState } from 'react';

const LoginRegister = () => {
  const [isLogin, setIsLogin] = useState(true);  // Alterna entre login y registro
  const [formData, setFormData] = useState({
    Nombre: '',
    Correo: '',
    Contraseña: '',
    TipoUsuario: 'Estudiante',  // Valor por defecto
  });

  // Cambiar entre el formulario de login y el de registro
  const switchMode = () => {
    setIsLogin(!isLogin);
    setFormData({ Nombre: '', Correo: '', Contraseña: '', TipoUsuario: 'Estudiante' });
  };

  const backendUrl = process.env.REACT_APP_BACKEND_URL;
  // Maneja el envío del formulario
  const handleSubmit = async (e) => {
    e.preventDefault();

    const url = isLogin ? `${backendUrl}/login` : `${backendUrl}/register`;

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      
      const result = await response.json();

      if (response.ok) {
        alert(isLogin ? 'Inicio de sesión exitoso' : 'Registro exitoso');
        if (isLogin) {
          localStorage.setItem('token', result.token);  // Guardar el token JWT si inicia sesión
        }
      } else {
        alert(result.message || 'Ocurrió un error');
      }
    } catch (error) {
      alert('Error en la solicitud: ' + error.message);
    }
  };

  return (
    <div style={styles.container}>
      <h2>{isLogin ? "Iniciar Sesión" : "Registro de Usuario"}</h2>
      <form style={styles.form} onSubmit={handleSubmit}>
        {!isLogin && (
          <>
            <input
              style={styles.input}
              type="text"
              placeholder="Nombre"
              name="Nombre"
              value={formData.Nombre}
              onChange={(e) => setFormData({ ...formData, Nombre: e.target.value })}
              required
            />
            <select
              style={styles.input}
              name="TipoUsuario"
              value={formData.TipoUsuario}
              onChange={(e) => setFormData({ ...formData, TipoUsuario: e.target.value })}
            >
              <option value="Estudiante">Estudiante</option>
              <option value="Padre">Padre</option>
              <option value="Educador">Educador</option>
              <option value="Admin">Admin</option>
            </select>
          </>
        )}
        <input
          style={styles.input}
          type="email"
          placeholder="Correo"
          name="Correo"
          value={formData.Correo}
          onChange={(e) => setFormData({ ...formData, Correo: e.target.value })}
          required
        />
        <input
          style={styles.input}
          type="password"
          placeholder="Contraseña"
          name="Contraseña"
          value={formData.Contraseña}
          onChange={(e) => setFormData({ ...formData, Contraseña: e.target.value })}
          required
        />
        <button style={styles.button} type="submit">
          {isLogin ? "Iniciar Sesión" : "Registrarse"}
        </button>
      </form>
      <p onClick={switchMode} style={styles.switchText}>
        {isLogin ? "¿No tienes cuenta? Regístrate aquí" : "¿Ya tienes cuenta? Inicia sesión"}
      </p>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '400px',
    margin: '0 auto',
    padding: '20px',
    textAlign: 'center',
    backgroundColor: '#fff7f2',
    borderRadius: '8px',
    boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.1)',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px',
  },
  input: {
    padding: '10px',
    fontSize: '16px',
    borderRadius: '4px',
    border: '1px solid #ccc',
  },
  button: {
    padding: '10px',
    fontSize: '18px',
    backgroundColor: '#ff9757',
    color: '#fff',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  switchText: {
    color: '#ff9757',
    cursor: 'pointer',
    marginTop: '10px',
  },
};

export default LoginRegister;
